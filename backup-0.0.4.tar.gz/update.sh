#!/bin/bash
cd hassio-addons-master
git push -u origin master
