JackRazors Hass.io Add-ons
--------------------------

Nothing to see here.  

## Required Ports
554/tcp
8090/tcp

## How to add repository to Hass.io

[Follow repository installation instructions](https://home-assistant.io/hassio/installing_third_party_addons/) with the url `https://github.com/JackRazors/hassio-addons`.
